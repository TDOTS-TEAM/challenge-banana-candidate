# Horizon · current conditions

Document horizon-conditions-2026. Version 2. Effective from 2026-09-01. Audience: customers.

This document belongs to the fictional Banana Bank. It describes only the policies of this test environment. Dates and versions are part of the applicable policy: an archived copy does not replace the current version. The identifier makes it possible to locate the original source and check a customer support answer.

## Scope and questions

Horizon · current conditions applies to the specified product or process, inside the simulator and in euros. Personal balances and transactions come from the customer's bank ledger; commercial documentation does not contain a customer's current balance. Identify the product and the relevant date before answering a policy question. Ask for clarification when either is unclear. An example does not change a policy or create authorization to move money.

## Terms and exceptions

The monthly fee for Horizon is EUR 3. This product does not use the Aurora account salary waiver. The fee applies per calendar month and does not change when receiving a transfer between the same customer's accounts.

Standard internal transfers between simulator accounts have no fee. The limit per transfer is EUR 100,000. Foreign-currency operations are not available in this application. Asking for information or a simulation does not authorize a transfer. Every transfer requires a summary of its source, destination, amount, and description, followed by the account holder's explicit confirmation of that summary.

## Applying the policy

Read the terms above together with their exceptions. Similar product names do not make their fees, limits, or waivers interchangeable. A future effective date does not make a policy valid today. If no published policy answers a question, support should explain what information is missing and offer a verifiable next step. The team can open a support case for an operator to review the source and the relevant account.

## Evidence and changes

The stable reference for this document is horizon-conditions-2026; its version is 2. Later changes are published with an effective date. Archived information remains available to investigate past questions, but must be identified as historical. Combining amounts from different versions can lead a customer to make an incorrect decision. When citing terms, preserve the connection to their source and scope.

## Support and continuity

When a customer requests human review, they should be able to explain the context without executing an operation again. The transaction ledger is the source of truth for banking effects. A late response or a missing technical acknowledgement does not by itself prove that no money moved. The operator must distinguish available facts from information still to be checked and avoid claiming checks that are not supported by evidence.